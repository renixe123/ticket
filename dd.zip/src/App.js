import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import TicketForm from './form/TicketForm';
import EventTicket from './Ticket';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<TicketForm />} />
        <Route path="/ticket/:ticketId" element={<EventTicket />} /> {/* Use EventTicket component here */}
      </Routes>
    </Router>
  );
}

export default App;
